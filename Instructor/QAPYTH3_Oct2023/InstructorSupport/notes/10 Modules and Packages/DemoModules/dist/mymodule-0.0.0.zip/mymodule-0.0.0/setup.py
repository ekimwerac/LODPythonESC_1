from distutils.core import setup

setup(
    name = "mymodule",
    #version = "1.0",
    py_modules = ['mymodule'],
    )
