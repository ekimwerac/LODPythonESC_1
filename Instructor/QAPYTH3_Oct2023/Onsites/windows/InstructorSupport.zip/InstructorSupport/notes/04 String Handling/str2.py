
str = 'hello';

print (str.capitalize())
print (str.upper())
print ('<'+str.center(12)+'>')
print ('<'+str.ljust(12)+'>')
print ('<'+str.rjust(12)+'>')
print ('<'+str.zfill(12)+'>')