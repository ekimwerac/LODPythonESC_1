import sys

var1 = 42

def myfunc1():
    print ("Hello!")
    
def myfunc2():
    print ("Goodbye!")
    
    