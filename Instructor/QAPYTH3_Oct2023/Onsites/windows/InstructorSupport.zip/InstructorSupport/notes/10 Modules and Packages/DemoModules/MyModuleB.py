import sys

var1 = 42

def MyFunc1():
    print ("Hello from", __name__)
    
def MyFunc2():
    print ("Goodbye from", __name__)
    
    