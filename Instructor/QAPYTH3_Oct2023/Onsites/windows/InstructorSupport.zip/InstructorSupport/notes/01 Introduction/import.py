#import sys
#print (sys.platform)


from sys import *
print (platform)