
import showcard

number = input("Pick a card (1-52):")

filename = "BMP"+number+".gif"
showcard.display_file(filename)

    
