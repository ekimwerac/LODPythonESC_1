
with open('gash.txt', 'r') as var:
    for line in var:
        print(line,end='')

print(var)


