print ("Hollow world")
exit(42)