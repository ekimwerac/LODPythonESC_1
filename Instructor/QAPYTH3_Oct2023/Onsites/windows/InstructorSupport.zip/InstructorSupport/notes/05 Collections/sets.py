setA = set('John')
setB = set('Jane')
print (setA, setB)

setA.add('y')
setB.remove('e')
print (setA, setB)

print (setA & setB)
print (setA | setB)
print (setA - setB)
print (setA ^ setB)
