
num = 42
txt = "3"

#if txt < num:
#    print ('Wow!')
#else:
#    print ('Doh!')
    
if int(txt) < num:
    print ('Wow!')
else:
    print ('Doh!')
    
alist = ['one', 'two', 'three', 'four']
blist = ['one', 'two', 'mzipjk', 'four']

if alist == blist:
    print ("Lists are equal")
    
alist = blist

if alist == blist:
    print ("Lists are equal")
    
    
    

