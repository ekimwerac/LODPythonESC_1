output = open ('myfile.txt', 'w');
#print >> output, "Hello";
print ("Hello", file=output)
