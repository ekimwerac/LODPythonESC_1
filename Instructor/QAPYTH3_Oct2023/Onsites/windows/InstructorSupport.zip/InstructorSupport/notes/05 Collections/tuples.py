#a,b = b,a			
Gouda, Edam, Caithness = range(3)
print (Gouda, Edam, Caithness)

mytuple = ('a','b','c')
another = mytuple * 4
print (another)


tup = 'Hello'
print (len(tup))

tup = 'Hello',
print (len(tup))

thing = ('Hello')
print ('thing is a ' + str(type(thing)))

thing = ('Hello',)
print ('thing is a ' + str(type(thing)))

