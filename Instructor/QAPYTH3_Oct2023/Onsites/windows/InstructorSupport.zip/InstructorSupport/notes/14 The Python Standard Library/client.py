# client.py
import time

print ('client.py')
time.sleep(10)
print ('client ending')