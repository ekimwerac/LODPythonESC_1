from BallClasses import *

one = BasketBall()

two = _Ball()