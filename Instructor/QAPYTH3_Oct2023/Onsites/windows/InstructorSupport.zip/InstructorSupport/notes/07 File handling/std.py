import sys
sys.stdout.write ("Please enter a value:")
sys.stdout.flush()
reply = sys.stdin.readline ()
print ("<",reply,"> was input")

reply = input("Please enter a value:")
print ("<",reply,"> was input")

