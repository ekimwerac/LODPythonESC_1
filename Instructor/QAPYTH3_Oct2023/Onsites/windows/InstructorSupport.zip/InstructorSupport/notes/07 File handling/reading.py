lines = file('brian.txt').read()

llines= open('brian.txt').read()
print(llines)
#llines.encode().split('\n')

"""
linelist = open('brian.txt').readlines()

for line1 in open('lines.txt').readlines():
    print (line1, end="")
    
print ()

for line2 in open('lines.txt') :
    print (line2, end="")
"""

        

