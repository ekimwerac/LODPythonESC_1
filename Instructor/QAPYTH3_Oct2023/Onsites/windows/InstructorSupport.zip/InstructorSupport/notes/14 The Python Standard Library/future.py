import sys, os
import __future__
   
print (__future__.all_feature_names)    
print (__future__.absolute_import)
        

