import sys

input = sys.stdin.readline ()
print (input.upper())
