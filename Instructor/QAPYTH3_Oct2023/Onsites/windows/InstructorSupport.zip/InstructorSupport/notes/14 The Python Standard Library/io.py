import sys
import platform
print (sys.platform)
print ("Platform:",platform.plaform)
print ("Compiler:",platform.compiler)
print ("Python  :",platform.python_version)


        

