print  ('\r\n \1\2\3')
print (r'\r\n \1\2\3')
