# Note: this will fail if run on cmd.exe

for line in open('utf8file.txt'):
#for line in open('utf8file.txt',encoding='utf8'):
    print(line)

