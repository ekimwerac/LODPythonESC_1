a = 42
b = 9

print (a + b)
print (type(a))

a = 'Hello '
b = 'World!'

print (a + b)
print (type(a))