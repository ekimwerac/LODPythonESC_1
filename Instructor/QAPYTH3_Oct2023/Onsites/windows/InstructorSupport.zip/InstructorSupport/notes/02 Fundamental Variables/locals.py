x = 42
y = 'Hello'
print (locals())

