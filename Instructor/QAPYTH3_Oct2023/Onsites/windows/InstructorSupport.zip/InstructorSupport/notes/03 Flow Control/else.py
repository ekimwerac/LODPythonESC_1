
i = 1
j = 1
while i < 42:
    i = i * 3
    j = j + 1
    print i
else:
    print i
