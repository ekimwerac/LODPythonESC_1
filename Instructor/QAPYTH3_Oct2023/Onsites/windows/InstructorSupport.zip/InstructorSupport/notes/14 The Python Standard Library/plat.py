import sys, os
import platform

print (sys.platform)
print (os.uname())
print ("Platform:",platform.platform())
print ("Compiler:",platform.python_compiler())
print ("Python  :",platform.python_version())
print ("LibC :",platform.libc_ver())



        

