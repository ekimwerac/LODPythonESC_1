import sys
import pdb

sys.path.append('./DemoModules')
from person import Person

pdb.run ('me = Person ("Clive Darke", "m")')
print ('This is me',me)

