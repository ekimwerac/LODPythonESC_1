
#print u"fred"
#print unicode("fred")

chars_as_bytes = b"single-byte string"

print (chars_as_bytes)

# Note: will fail on Windows cmd.exe
#euro = "\u20ac"
#print (euro)

#euro = "\N{euro sign}"
#print (euro)

print (r"C:\Numbers")