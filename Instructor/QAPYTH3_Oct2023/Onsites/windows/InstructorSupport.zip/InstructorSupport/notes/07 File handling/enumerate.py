
for pos, char in enumerate("Hello world"):
    print (pos, char)

for nr,line in enumerate(open('brian.txt'), start=3) :
    print (nr+1,line, end="")


        

